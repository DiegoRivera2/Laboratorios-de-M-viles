package com.vanegas1.lab2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    private lateinit var HeightEditText: EditText
    private lateinit var WeightEditText: EditText
    private lateinit var CalculateButton: Button
    private lateinit var ResultText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        bind()


    }

    fun bind(){
        HeightEditText = findViewById(R.id.height_editText)
        WeightEditText = findViewById(R.id.weight_editText)
        CalculateButton = findViewById(R.id.calculate_btn)
        ResultText = findViewById(R.id.result_text)
    }
}